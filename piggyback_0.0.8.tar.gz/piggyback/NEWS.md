# piggyback 0.0.8

* Updates to documentation, streamlining tests
* remove dependency on `utils::askYesNo` which is only available in R >= 3.5.0

# piggyback 0.0.7 2018-10-01

* Initial release to CRAN

# piggyback 0.0.6 2018-09-21

* bugfix for migrating unit test

# piggyback 0.0.6 2018-09-21

* bugfix for migrating unit test, JOSS submission

# piggyback 0.0.5 2018-09-21

* initial Onboarding to rOpenSci

# piggyback 0.0.0.9000

* Added a `NEWS.md` file to track changes to the package.
